/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package org.jboss.txbridge.ba.execute;

import org.jboss.txbridge.ba.data.TaskDescription;
import org.jboss.txbridge.ba.service.MethodDescription;
import org.jboss.txbridge.ba.datamgmt.ExecutionDataProvider;
import org.jboss.txbridge.ba.datamgmt.DataManagerImpl;
import org.jboss.txbridge.ba.exception.ActionExecutionException;
import org.apache.log4j.Logger;

/**
 * This class represents a local service executor. This executor uses the LocalExecution class
 * as the execution mechanism by default.
 *
 * @author Maciej P. Machulak (mmachulak@redhat.com)
 * @version 0.1
 */
public class LocalServiceExecutor extends ServiceExecutor
{

    // Logger
    private static Logger log = Logger.getLogger(LocalServiceExecutor.class);

    public LocalServiceExecutor(TaskDescription taskDesc)
    {
        super(taskDesc);
        execution = new LocalExecution();
        dataProvider = new ArgumentsProvider();
    }

    public void invoke(MethodDescription md, ExecutionDataProvider edp)
            throws ActionExecutionException
    {
        log.info("invoke()");
        log.info("Getting list of arguments");
        Object[] arguments = dataProvider.getArguments(md,edp);
        log.info("Getting list of argument types");
        Class[] argumentTypes = dataProvider.getArgumentTypes(arguments);
        Long threadId = Thread.currentThread().getId();
        log.info("Associating data manager to thread: " + threadId);
        cmp.associateManager(threadId,new DataManagerImpl(taskDescription.getTaskId(),taskDescription.getParticipant()));
        try
        {
            execution.invokeService(taskDescription,md,arguments,argumentTypes);
            log.info("Removing data manager association for thread: " + threadId);
            cmp.removeManager(threadId);
        }
        catch (ActionExecutionException e)
        {
            log.info("Removing data manager association for thread: " + threadId);
            cmp.removeManager(threadId);
            throw new ActionExecutionException(e);
        }
    }

}
