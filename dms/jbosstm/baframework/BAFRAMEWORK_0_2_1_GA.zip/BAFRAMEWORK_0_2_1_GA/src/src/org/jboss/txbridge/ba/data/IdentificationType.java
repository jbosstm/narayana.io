/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package org.jboss.txbridge.ba.data;

/**
 * List of supported identification types. Identification type defines how managed
 * data should be processed when executing the completion or compensation action.
 * If data has been remembered with textual identifiers (names) then the signature of the
 * action (completion or compensation) must provide information how this data can be matched
 * with parameters of that action. If identifiers are represented by numbers then the execution
 * mechanism simply use managed data in the required order (this can be used for
 * remote completion or compensation where third-party services are used).
 *
 * @author Maciej P. Machulak (mmachulak@redhat.com)
 * @version 0.1
 */
public enum IdentificationType
{
    BY_NUMBER,
    BY_NAME    
}
