/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package org.jboss.txbridge.ba.execute;

import org.apache.log4j.Logger;
import org.jboss.txbridge.ba.data.TaskDescription;
import org.jboss.txbridge.ba.exception.ActionExecutionException;
import org.jboss.txbridge.ba.service.MethodDescription;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

/**
 * This class provides implementation of the local execution. Local execution is used 
 * on POJOs.
 *
 * @author Maciej P. Machulak (mmachulak@redhat.com)
 * @version 0.1
 */
public class LocalExecution implements Executable {
    // Logger
    private static Logger log = Logger.getLogger(LocalExecution.class);

    /**
     * This method invokes a service that is described by the service description with given arguments
     * and argument types.
     *
     * @param taskDesc describes the task (needed to inject the proper participant).
     * @param md describes the service.
     * @param arguments is the list of arguments.
     * @param argumentTypes is the list of argument types.
     * @throws ActionExecutionException if invoking service was not successful.
     */
    public void invokeService(TaskDescription taskDesc, MethodDescription md, Object[] arguments, Class[] argumentTypes)
            throws ActionExecutionException
    {
        log.info("invoke()");

        try
        {
            // 1) Get the class of the method
            Class clazz = md.getClazz();
            log.info("Compensation class: " + clazz.getName());
            // 2) Get the name of the method
            String methodName = md.getMethodName();
            log.info("Compensation method: " + methodName);
            // 3) Get the method
            log.info("Getting reference to the method...");
            Method compensationMethod = clazz.getMethod(methodName,argumentTypes);
            if ( compensationMethod == null )
            {
                throw new ActionExecutionException("Could not get access to the method");
            }
            // 4) Invoke the service
            log.info("Getting reference to the class constructor");
            Constructor classConstructor = clazz.getConstructor();
            log.info("Constructor: " + classConstructor.toString());
            Object classObject = classConstructor.newInstance();
            log.info("Invoking a service");
            compensationMethod.invoke(classObject,arguments);
        }
        catch (Exception e)
        {
            throw new ActionExecutionException(e.getMessage());
        }
    }

}
