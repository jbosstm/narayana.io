/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package org.jboss.txbridge.ba.datamgmt;

/**
 * This class represents a dummy data manager. Such dummy data manager is used
 * if a Web Service is invoked outside the scope of the Business Activity. It provides same
 * methods as a normal data manager but does not store any values and always returns null.
 *
 * @author Maciej P. Machulak (mmachulak@redhat.com)
 * @version 0.1
 */
public class DummyDataManager implements DataManager
{
    /**
     * This is a dummy method that... does nothing.
     *
     * @param objectId is the ID of the object.
     * @param object is the object itself.
     */
    public void put(Object objectId, Object object)
    {       
    }

    /**
     * This method does nothing - simply returns null.
     *
     * @param objectId is the object id.
     * @return returns always null.
     */
    public Object get(Object objectId)
    {
        return null;
    }
}
