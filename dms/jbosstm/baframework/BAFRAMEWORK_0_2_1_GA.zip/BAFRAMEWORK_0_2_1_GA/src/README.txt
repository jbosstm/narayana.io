JBoss, Home of Professional Open Source
Copyright 2007, Red Hat Middleware LLC, and individual contributors
as indicated by the @author tags. 
See the copyright.txt in the distribution for a full listing 
of individual contributors.
This copyrighted material is made available to anyone wishing to use,
modify, copy, or redistribute it subject to the terms and conditions
of the GNU General Public License, v. 2.0.
This program is distributed in the hope that it will be useful, but WITHOUT A 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
PARTICULAR PURPOSE.  See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License,
v. 2.0 along with this distribution; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
MA  02110-1301, USA.
  
(C) 2007,
@author JBoss Inc.

### Business Activity Framework & Demo Application
### Version: 0.1
### Date: July 31, 2007
### Author: Maciej Machulak (mmachulak@redhat.com)
### WWW: http://labs.jboss.com/jbosstm/baframework

Contents:
1. Introduction
2. Building Business Activity Framework
3. Building Business Activity Demo Application
4. Other documentation


### 1. Introduction

The Business Activity Framework is a fully novel comprehensive solution for building
transactional Web Services with accordance to the model defined in the WS-BusinessActivity
specification. It provides a lightweight API that consists of a set of easy to learn and 
intuitive annotations and operations. It significantly facilitates development of transaction 
aware Web Services and releases programmers from mixing transaction related code with business 
logic of their applications. 
Web Services must be simply annotated with a set of defined annotations and the framework
transparently applies all necessary transactional mechanisms to enable participation in
long-running Business Activities.

IMPORTANT NOTICE:
This is the first release of the framework and is aimed mainly for testing. 

It it assumed that demo application is tested locally - Coordinator has been set to 
following address: http://localhost:8080. This is set in the following file:
ws-c.war (WEB-INF/web.xml)

  <init-param>
    <param-name>BaseHttpURI</param-name>
    <param-value>http://localhost:8080/xts/soap/</param-value>
  </init-param>

The client application uses the http://localhost:8080 address to lookup Web Services
by default as well. This can be changed in the following source file:
com/jboss/ba/demo/client/HotelService.java

JBoss Application Server on which the Business Activity Framework is to be used must be
able to understand aspects (using JBoss AOP framework). By default JBoss AOP is bundled
with the application server. For information how to enable this
feature please refer to the JBoss AOP documentation.


### 2. Building Business Activity framework

Building the BA Framework requires following components:
- JDK (version 1.5)
  (available at http://java.sun.com/javase/downloads/index_jdk5.jsp)
- Ant build tool (version 1.7.0)
  (available at http://ant.apache.org/)
- JBoss Application Server (version 4.2.0 GA)
  (available at http://labs.jboss.com/jbossas/)
- JBoss Transaction Service (version 4.2.3 SP5)
  (available at http://labs.jboss.com/jbosstm/)

1) Edit 'build.xml' file and set following properties:
   - jboss.home (i.e. "/home/mmachulak/dev/jboss-4.2.0.GA")
   - xts.home" (i.e. "/home/mmachulak/dev/JBossTS/XTS/xts-install")

2) Run 'ant'
   This produces following files:
   - build/baframework-client.jar
   - build/baframework.aop

   'baframework-client.jar' file needs to be in the classpath of the application that wants
   to use the framework. 
   'baframework.aop' file must be deployed with the application as shown in the following
   example of application.xml file:

	<application>
	    <module>
		<ejb>MyEJB.jar</ejb>
	    </module>

	    <module>
		<java>baframework.aop</java>
	    </module>
	</application>
    
    For the use of the demo application it is not necessary to copy those files anywhere.


### 3. Building Business Activity Demo Application

Building the BA Framework Demo Application requires following components:
- JDK (version 1.5)
  (available at http://java.sun.com/javase/downloads/index_jdk5.jsp)
- Ant build tool (version 1.7.0)
  (available at http://ant.apache.org/)
- JBoss Application Server (version 4.2.0 GA)
  (available at http://labs.jboss.com/jbossas/)
- JBoss Transaction Service (version 4.2.3 SP5)
  (available at http://labs.jboss.com/jbosstm/)

1) Go to the demo/ directory (i.e. 'cd demo/')

2) Edit 'build.xml' file and set following properties:
   - jboss.home (i.e. "/home/mmachulak/dev/jboss-4.2.0.GA")
   - xts.home" (i.e. "/home/mmachulak/dev/JBossTS/XTS/xts-install")

3) Run 'ant'
   This produces the following file:
   - build/bademo.ear

   This archive contains the demo application (hotel.jar), the framework's client library
   (baframework-client.jar), the framework (baframework.aop) and the required infrastructure 
   for WS-BusinessActivity.
   
4) Run 'ant deploy'
   This copies the bademo.ear file to the deployment directory of the JBoss Application Server.

Demo application is accessible through the following address: http://localhost:8080/bademo

All necessary information related to using the demo application has been provided on web pages
that are the part of the demo application.


### 4. Other documentation

All documentation directly related to the Business Activity framework can be found on the 
website of this framework.
