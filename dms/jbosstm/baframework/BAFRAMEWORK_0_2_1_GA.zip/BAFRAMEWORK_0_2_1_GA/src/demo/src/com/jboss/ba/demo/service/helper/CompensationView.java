/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package com.jboss.ba.demo.service.helper;

import org.apache.log4j.Logger;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import java.awt.*;

/**
 * @author: Maciej P. Machulak
 * @date: Jul 31, 2007
 */
public class CompensationView extends JFrame
{
    private static Logger log = Logger.getLogger(CompensationView.class);

    private volatile static CompensationView compensationView;

    private JTextArea textArea;
    private JScrollPane scrollPane;
    private boolean compensationOn;

    private List<String> compensationList;

    public CompensationView()
    {
        setLayout(new BorderLayout());
        setSize(600,600);

        setTitle("BA Framework Test Application - Compensation Order");

        textArea = new JTextArea(240,20);
        scrollPane = new JScrollPane();

        scrollPane.setAutoscrolls(true);
        textArea.setEditable(false);
        textArea.setRows(10);
        textArea.setMargin(new java.awt.Insets(5, 5, 5, 5));
        scrollPane.setViewportView(textArea);

        getContentPane().add(scrollPane,BorderLayout.CENTER);
        setVisible(true);
        repaint();

        compensationList = new ArrayList<String>();

        compensationOn = true;
    }

    public static CompensationView getSingletonInstance()
    {
        if (compensationView == null)
        {
            synchronized(CompensationView.class)
            {
                if (compensationView == null)
                {
                    compensationView = new CompensationView();
                }
            }
        }
        return compensationView;
    }

    public void turn(boolean value)
    {
        compensationOn = value;
    }

    public void resetCompensationList()
    {
        compensationList.clear();
    }

    public void resetCompensationView()
    {
        textArea.setText("");
    }

    public void compensationMethod(String compensationMethod)
    {
        if (compensationOn)
        {
            log.info("compensationMethod()");
            compensationList.add(compensationMethod);
            showCompensation(compensationList);
        }
    }

    private void showCompensation(List<String> compensationList)
    {
        log.info("showCompensation()");
        textArea.setText("");
        textArea.append("Compensation order:\n");
        int counter = 0;
        for (int i = compensationList.size(); i > 0 ; i--)
        {
            textArea.append((counter+1) + ") " + compensationList.get(i-1) + "\n");
            counter++;
        }
        textArea.append("---");
        textArea.append("\nTotal number of compensation actions: " + counter);
    }
}
