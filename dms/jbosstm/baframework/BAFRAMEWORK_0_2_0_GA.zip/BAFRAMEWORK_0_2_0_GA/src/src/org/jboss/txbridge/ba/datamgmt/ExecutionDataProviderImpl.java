/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package org.jboss.txbridge.ba.datamgmt;

import org.jboss.txbridge.ba.participant.Participant;
import org.apache.log4j.Logger;

/**
 * @author Maciej P. Machulak (mmachulak@redhat.com)
 * @version 0.1
 */
public class ExecutionDataProviderImpl extends DataManagerImpl implements ExecutionDataProvider
{
    // Logger
    private static Logger log = Logger.getLogger(DataManagerImpl.class);

    /**
     * Constructor
     *
     * @param taskId is the task identifier.
     * @param participant is the reference to the participant.
     */
    public ExecutionDataProviderImpl(String taskId, Participant participant)
    {
        super(taskId,participant);
    }

    /**
     *
     *
     * @param arguments is the list of parameters.
     */
    public void putArguments(Object[] arguments)
    {
        log.info("putArguments()");
        participant.putArguments(taskId,arguments);
    }

    /**
     *
     *
     * @return the list of parameters.
     */
    public Object[] getArguments()
    {
        log.info("getArguments()");
        return participant.getArguments(taskId);
    }

    /**
     *
     *
     * @param returnObject the return object that should be remembered.
     */
    public void putReturn(Object returnObject)
    {
        log.info("putReturn()");
        participant.putReturn(taskId,returnObject);
    }

    /**
     *
     *
     * @return the return object associated with a given task.
     */
    public Object[] getReturn()
    {
        log.info("getReturn()");
        return participant.getReturn(taskId);
    }

}
