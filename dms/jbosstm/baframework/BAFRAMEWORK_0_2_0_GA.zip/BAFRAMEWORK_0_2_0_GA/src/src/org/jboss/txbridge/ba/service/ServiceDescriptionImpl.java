/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package org.jboss.txbridge.ba.service;

import org.jboss.txbridge.ba.annotation.*;

import java.util.Map;
import java.util.HashMap;

/**
 * This class describes the service in terms of all its requirements related to participation
 * in Business Activities.
 *
 * TODO: Redesign this - it's really inefficient now!
 *
 *
 * @author Maciej P. Machulak (mmachulak@redhat.com)
 * @version 0.1
 */
public class ServiceDescriptionImpl implements ServiceDescription
{

    /**
     * BA-related information.
     */
    private MethodType methodType;
    private AgreementType agreementType;

    private Map<String,MethodDescription> methods;


    //TODO: This should be separate for completion and datamgmt!!
    private DataMatch dataMatch;
    private ExecutionMode executionMode;
    private ParameterMatch parameterMatch;

    /**
     * Information about the original method.
     */
    private MethodDescription originalMethod;

    /**
     * Information about the datamgmt method.
     */
    private MethodDescription compensationMethod;

    /**
     * Information about the completion method
     */
    private MethodDescription completionMethod;

    public ServiceDescriptionImpl()
    {
        methods = new HashMap<String,MethodDescription>();
        originalMethod = new MethodDescriptionImpl();
        compensationMethod = new MethodDescriptionImpl();
        completionMethod = new MethodDescriptionImpl();
    }

    public MethodType getMethodType()
    {
        return methodType;
    }

    public void setMethodType(MethodType methodType)
    {
        this.methodType = methodType;
    }

    public AgreementType getAgreementType()
    {
        return agreementType;
    }

    public void setAgreementType(AgreementType agreementType)
    {
        this.agreementType = agreementType;
    }

    public void putMethod(String methodName, MethodDescription method)
    {
        this.methods.put(methodName,method);
    }

    public MethodDescription getMethod(String methodName)
    {
        return this.methods.get(methodName);
    }




















    public DataMatch getDataMatch()
    {
        return dataMatch;
    }

    public void setDataMatch(DataMatch dataMatch)
    {
        this.dataMatch = dataMatch;
    }

    public ExecutionMode getExecutionMode()
    {
        return executionMode;
    }

    public void setExecutionMode(ExecutionMode executionMode)
    {
        this.executionMode = executionMode;
    }

    public ParameterMatch getParameterMatch()
    {
        return parameterMatch;
    }

    public void setParameterMatch(ParameterMatch parameterMatch)
    {
        this.parameterMatch = parameterMatch;
    }

    public Class getOriginalClass()
    {
        return originalMethod.getClazz();
    }

    public void setOriginalClass(Class originalClass)
    {
        originalMethod.setClazz(originalClass);
    }

    public String getOriginalMethodName()
    {
        return originalMethod.getMethodName();
    }

    public void setOriginalMethodName(String originalMethodName)
    {
        originalMethod.setMethodName(originalMethodName);
    }

    public String getOriginalWebMethodName()
    {
        return originalMethod.getWebMethodName();
    }

    public void setOriginalWebMethodName(String originalWebMethodName)
    {
        originalMethod.setWebMethodName(originalWebMethodName);
    }

    public Class getOriginalReturnType()
    {
        return originalMethod.getReturnType();
    }

    public void setOriginalReturnType(Class originalReturnType)
    {
        originalMethod.setReturnType(originalReturnType);
    }

    public Class[] getOriginalParameterTypes()
    {
        return originalMethod.getParameterTypes();
    }

    public void setOriginalParameterTypes(Class[] originalParameterTypes)
    {
        originalMethod.setParameterTypes(originalParameterTypes);
    }

    public Object getOriginalReturnId()
    {
        return originalMethod.getReturnId();
    }

    public void setOriginalReturnId(Object originalReturnId)
    {
        originalMethod.setReturnId(originalReturnId);
    }

    public Object[] getOriginalParameterAnnotations()
    {
        return originalMethod.getParameterAnnotations();
    }

    public void setOriginalParameterAnnotations(Object[] originalParameterAnnotation)
    {
        originalMethod.setParameterAnnotations(originalParameterAnnotation);
    }

    public Class getCompensationClass()
    {
        return compensationMethod.getClazz();
    }

    public void setCompensationClass(Class compensationClass)
    {
        compensationMethod.setClazz(compensationClass);
    }

    public String getCompensationMethodName()
    {
        return compensationMethod.getMethodName();
    }

    public void setCompensationMethodName(String compensationMethodName)
    {
        compensationMethod.setMethodName(compensationMethodName);
    }

    public String getCompensationWebMethodName()
    {
        return compensationMethod.getWebMethodName();
    }

    public void setCompensationWebMethodName(String compensationWebMethodName)
    {
        compensationMethod.setWebMethodName(compensationWebMethodName);
    }

    public Class getCompensationReturnType()
    {
        return compensationMethod.getReturnType();
    }

    public void setCompensationReturnType(Class compensationReturnType)
    {
        compensationMethod.setReturnType(compensationReturnType);
    }

    public Class[] getCompensationParameterTypes()
    {
        return compensationMethod.getParameterTypes();
    }

    public void setCompensationParameterTypes(Class[] compensationParameterTypes)
    {
        compensationMethod.setParameterTypes(compensationParameterTypes);
    }

    public Object[] getCompensationParameterAnnotations()
    {
        return compensationMethod.getParameterAnnotations();
    }

    public void setCompensationParameterAnnotations(Object[] compensationParameterAnnotations)
    {
        compensationMethod.setParameterAnnotations(compensationParameterAnnotations);
    }

    public String getCompensationJNDIName()
    {
        return compensationMethod.getJndiName();
    }

    public void setCompensationJNDIName(String jndiName)
    {
        compensationMethod.setJndiName(jndiName);
    }

    public String getCompensationProviderURL()
    {
        return compensationMethod.getProviderURL();
    }

    public void setCompensationProviderURL(String providerURL)
    {
        compensationMethod.setProviderURL(providerURL);
    }

    public boolean isCompensationSingle()
    {
        return methods.get("compensate").isSingle();
    }

    public void setCompensationSingle(boolean value)
    {
        compensationMethod.setSingle(value);
    }

    public Class getCompensationEjbInterface()
    {
        return compensationMethod.getEjbInterface();
    }

    public void setCompensationEjbInterface(Class ejbInterface)
    {
        compensationMethod.setEjbInterface(ejbInterface);
    }

    public Class getCompletionClass()
    {
        return completionMethod.getClazz();
    }

    public void setCompletionClass(Class completionClass)
    {
        completionMethod.setClazz(completionClass);
    }

    public String getCompletionMethodName()
    {
        return completionMethod.getMethodName();
    }

    public void setCompletionMethodName(String completionMethodName)
    {
        completionMethod.setMethodName(completionMethodName);
    }

    public String getCompletionWebMethodName()
    {
        return completionMethod.getWebMethodName();
    }

    public void setCompletionWebMethodName(String completionWebMethodName)
    {
        completionMethod.setWebMethodName(completionWebMethodName);
    }

    public Class getCompletionReturnType()
    {
        return completionMethod.getReturnType();
    }

    public void setCompletionReturnType(Class completionReturnType)
    {
        completionMethod.setReturnType(completionReturnType);
    }

    public Class[] getCompletionParameterTypes()
    {
        return completionMethod.getParameterTypes();
    }

    public void setCompletionParameterTypes(Class[] completionParameterTypes)
    {
        completionMethod.setParameterTypes(completionParameterTypes);
    }

    public Object[] getCompletionParameterAnnotations()
    {
        return completionMethod.getParameterAnnotations();
    }

    public void setCompletionParameterAnnotations(Object[] completionParameterAnnotations)
    {
        completionMethod.setParameterAnnotations(completionParameterAnnotations);
    }

    public String getCompletionJNDIName()
    {
        return completionMethod.getJndiName();
    }

    public void setCompletionJNDIName(String jndiName)
    {
        completionMethod.setJndiName(jndiName);
    }

    public String getCompletionProviderURL()
    {
        return completionMethod.getProviderURL();
    }

    public void setCompletionProviderURL(String providerURL)
    {
        completionMethod.setProviderURL(providerURL);
    }

    public boolean isCompletionSingle()
    {
        return methods.get("complete").isSingle();
    }

    public void setCompletionSingle(boolean value)
    {
        completionMethod.setSingle(value);
    }

    public Class getCompletionEjbInterface()
    {
        return completionMethod.getEjbInterface();
    }

    public void setCompletionEjbInterface(Class ejbInterface)
    {
        completionMethod.setEjbInterface(ejbInterface);
    }

    public MethodDescription getCompletionService()
    {
        return methods.get("complete");
    }

    public MethodDescription getCompensationService()
    {
        return methods.get("compensate");
    }

}
