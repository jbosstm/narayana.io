/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package org.jboss.txbridge.ba.datamgmt;

import org.apache.log4j.Logger;

import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * This component is responsible for ensuring that a proper Data Manager is provided
 * during execution of a service or a datamgmt action. It associates datamgmt managers
 * with proper threads of execution.
 *
 * @author Maciej P. Machulak (mmachulak@redhat.com)
 * @version 0.1
 */
public class DataManagerProvider
{
    private static Logger log = Logger.getLogger(DataManagerProvider.class);

    private static volatile DataManagerProvider cmp = null;

    private static ConcurrentMap<Long, DataManager> cmList;

    private DataManagerProvider()
    {
        cmList = new ConcurrentHashMap<Long, DataManager>();
    }

    /**
     * Returns the instance fo a datamgmt manager provider.
     *
     * @return the datamgmt manager.
     */
    public static DataManagerProvider getSingletonInstance()
    {
        log.info("getSingletonInstance()");
        if (cmp == null)
        {
            synchronized (DataManagerProvider.class)
            {
                if (cmp == null)
                {
                    log.info("Creating a new instance");
                    cmp = new DataManagerProvider();
                }
            }
        }
        return cmp;
    }

    /**
     * This method associates a datamgmt manager with a given thread of execution.
     *
     * @param thread is the thread for which the datamgmt manager should be associated.
     * @param cmp is the datamgmt manager, which should be associated.
     */
    public void associateCompensationManager(Long thread, DataManager cmp)
    {
        log.info("associateCompensationManager()");
        cmList.put(thread,cmp);
    }

    /**
     * This method returns the datamgmt manager object associated to a certain thread of execution.
     * If there is no datamgmt manager associated to a certain thread of execution then it means
     * the service is being executed outside the scope of the Business Activity and a dummy datamgmt
     * manager is simply returned.
     *
     * @param thread thread ID for which the datamgmt manager should be returned.
     * @return the DataManager object.
     */
    public DataManager getCompensationManager(Long thread)
    {
        log.info("getCompensationManager()");
        DataManager cm = cmList.get(thread);
        if (cm == null)
        {
            log.info("Returning a dummy datamgmt manager");
            cm = new DummyDataManager();
        }
        return cm;
    }

    /**
     * This method removes the association of a thread and a datamgmt manager.
     *
     * @param thread is the thread for which the associaction should be removed.
     */
    public void removeCompensationManager(Long thread)
    {
        log.info("removeCompensationManager()");
        cmList.remove(thread);
    }
}
