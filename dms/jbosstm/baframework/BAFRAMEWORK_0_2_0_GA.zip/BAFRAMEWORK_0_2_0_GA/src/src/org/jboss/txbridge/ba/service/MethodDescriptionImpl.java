/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package org.jboss.txbridge.ba.service;

import org.jboss.txbridge.ba.annotation.DataMatch;
import org.jboss.txbridge.ba.annotation.ExecutionMode;
import org.jboss.txbridge.ba.annotation.ParameterMatch;

/**
 * This class describes a single method with all information related to participation
 * in Business Activities.
 *
 * TODO: Redesign this - it should be a simple map to hold all those values.
 *
 * @author Maciej P. Machulak (mmachulak@redhat.com)
 * @version 0.1
 */
public class MethodDescriptionImpl implements MethodDescription
{
    private Class clazz;
    private Class ejbInterface;
    private String methodName;
    private String webMethodName;
    private Class[] parameterTypes;
    private Object[] parameterAnnotations;
    private Object returnId;
    private Class returnType;
    private boolean isSingle;
    private DataMatch dataMatch;
    private ExecutionMode executionMode;
    private ParameterMatch parameterMatch;

    // TODO: Put this into a new class!
    private String jndiName;
    private String providerURL;

    public Class getClazz()
    {
        return clazz;
    }

    public void setClazz(Class clazz)
    {
        this.clazz = clazz;
    }

    public String getMethodName()
    {
        return methodName;
    }

    public void setMethodName(String methodName)
    {
        this.methodName = methodName;
    }

    public String getWebMethodName()
    {
        return webMethodName;
    }

    public void setWebMethodName(String webMethodName)
    {
        this.webMethodName = webMethodName;
    }

    public Class[] getParameterTypes()
    {
        return parameterTypes;
    }

    public void setParameterTypes(Class[] parameterTypes)
    {
        this.parameterTypes = parameterTypes;
    }

    public Object[] getParameterAnnotations()
    {
        return parameterAnnotations;
    }

    public void setParameterAnnotations(Object[] parameterAnnotations)
    {
        this.parameterAnnotations = parameterAnnotations;
    }

    public Object getReturnId()
    {
        return returnId;
    }

    public void setReturnId(Object returnId)
    {
        this.returnId = returnId;
    }

    public Class getReturnType()
    {
        return returnType;
    }

    public void setReturnType(Class returnType)
    {
        this.returnType = returnType;
    }

    public String getJndiName()
    {
        return jndiName;
    }

    public void setJndiName(String jndiName)
    {
        this.jndiName = jndiName;
    }

    public String getProviderURL()
    {
        return providerURL;
    }

    public void setProviderURL(String providerURL)
    {
        this.providerURL = providerURL;
    }

    public boolean isSingle()
    {
        return isSingle;
    }

    public void setSingle(boolean value)
    {
        this.isSingle = value;
    }

    public DataMatch getDataMatch()
    {
        return dataMatch;
    }

    public void setDataMatch(DataMatch compensationType)
    {
        this.dataMatch = compensationType;
    }

    public ExecutionMode getExecutionMode()
    {
        return executionMode;
    }

    public void setExecutionMode(ExecutionMode compensationMode)
    {
        this.executionMode = compensationMode;
    }

    public ParameterMatch getParameterMatch()
    {
        return parameterMatch;
    }

    public void setParameterMatch(ParameterMatch parameterMatch)
    {
        this.parameterMatch = parameterMatch;
    }

    public Class getEjbInterface()
    {
        return ejbInterface;
    }

    public void setEjbInterface(Class ejbInterface)
    {
        this.ejbInterface = ejbInterface;
    }
}
