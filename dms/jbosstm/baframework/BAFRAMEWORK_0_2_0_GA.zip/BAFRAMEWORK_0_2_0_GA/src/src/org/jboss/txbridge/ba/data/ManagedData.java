/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package org.jboss.txbridge.ba.data;

import org.apache.log4j.Logger;

import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentHashMap;
import java.io.Serializable;

/**
 * This class represents the basic datamgmt data that is used for datamgmt.
 * It provides implementation of methods to store and retrieve data with given identifiers.
 *
 * @author Maciej P. Machulak (mmachulak@redhat.com)
 * @version 0.1
 */
public class ManagedData implements Serializable
{

    // Logger
    private static Logger log = Logger.getLogger(ManagedData.class);

    // Array of parameters
    private Object[] arguments;

    // The return object
    private Object[] returnObject;

    private ConcurrentMap<Object,Object> compensationData;

    public ManagedData()
    {
        returnObject = new Object[1];
        compensationData = new ConcurrentHashMap<Object,Object>();
    }

    public Object get(Object key)
    {
        return compensationData.get(key);
    }

    public void put(Object key, Object value)
    {
        compensationData.put(key, value);
    }

    /**
     * This method stores arguments of the method's invocation.
     *
     * @param arguments is the array of arguments.
     */
    public void putArguments(Object[] arguments)
    {
        log.info("putArguments()");
        this.arguments = arguments;
    }

    /**
     * This method returns the array of arguments for a certain method invocation.
     *
     * @return is the array of arguments.
     */
    public Object[] getArguments()
    {
        log.info("getArguments()");
        return arguments;
    }

    public Object[] getReturnObject()
    {
        log.info("getReturnObject()");
        return returnObject;
    }

    public void putReturnObject(Object returnObject)
    {
        log.info("putReturnObject()");
        this.returnObject[0] = returnObject;
    }
}
