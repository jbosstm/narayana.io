/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package org.jboss.txbridge.ba.data;

import org.jboss.txbridge.ba.participant.Participant;

/**
 * Task Description contains all information related to a single service invocation (task).
 * - the transaction identifier
 * - the unique task identifier
 * - the service which the task relates to
 * - participant responsible for this task
 *
 * @author Maciej P. Machulak (mmachulak@redhat.com)
 * @version 0.1
 */
public class TaskDescription
{
    private String txId;
    private String taskId;
    private String serviceId;
    private Participant participant;


    public TaskDescription(String txId, String taskId, String serviceId, Participant participant)
    {
        this.txId = txId;
        this.taskId = taskId;
        this.serviceId = serviceId;
        this.participant = participant;
    }


    public String getTxId()
    {
        return txId;
    }

    public String getTaskId()
    {
        return taskId;
    }

    public String getServiceId()
    {
        return serviceId;
    }

    public Participant getParticipant()
    {
        return participant;
    }


    @Override
    public String toString()
    {
        StringBuffer sb = new StringBuffer();
        sb.append("TxID: ");
        sb.append(txId);
        sb.append(" TaskID: ");
        sb.append(taskId);
        sb.append(" ServiceID: ");
        sb.append(serviceId);
        sb.append(" Participant ref: ");
        sb.append(participant);
        return sb.toString();
    }

    public boolean equals(Object o)
    {
        if (this == o)
        {
            return true;
        }
        if (o == null || getClass() != o.getClass())
        {
            return false;
        }

        TaskDescription that = (TaskDescription) o;

        return participant.equals(that.participant) && serviceId.equals(that.serviceId) && taskId.equals(that.taskId) && txId.equals(that.txId);

    }

    public int hashCode()
    {
        int result;
        result = txId.hashCode();
        result = 31 * result + taskId.hashCode();
        result = 31 * result + serviceId.hashCode();
        result = 31 * result + participant.hashCode();
        return result;
    }
}
