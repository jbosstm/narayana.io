/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package org.jboss.txbridge.ba.execute;

import org.apache.log4j.Logger;
import org.jboss.txbridge.ba.datamgmt.ExecutionDataProvider;
import org.jboss.txbridge.ba.datamgmt.DataManagerProvider;
import org.jboss.txbridge.ba.datamgmt.DataManagerImpl;
import org.jboss.txbridge.ba.data.TaskDescription;
import org.jboss.txbridge.ba.exception.ActionExecutionException;
import org.jboss.txbridge.ba.service.MethodDescription;
import org.jboss.txbridge.ba.annotation.DataMatch;

/**
 * This is an abstract class that describes a basic ServiceExecutor. Service Executors are used for
 * executing datamgmt actions.
 *
 * @author Maciej P. Machulak (mmachulak@redhat.com)
 * @version 0.1
 */
public abstract class ServiceExecutor
{
    // Logger
    private static Logger log = Logger.getLogger(ServiceExecutor.class);

    // Compensation manager provider
    private static DataManagerProvider cmp = DataManagerProvider.getSingletonInstance();

    // Task description
    private TaskDescription taskDescription;

    // Execution interface
    ExecutionInterface execution;

    // Data provider
    org.jboss.txbridge.ba.execute.DataProvider dataProvider;


    /**
     * Main constructor.
     *
     * @param taskDesc is the task's description.
     */
    ServiceExecutor(TaskDescription taskDesc)
    {
        log.info("constructor()");
        this.taskDescription = taskDesc;
    }

    /**
     * Constructor.
     *
     * @param taskDesc is the task's description.
     * @param execution is the execution interface that should be used.
     * @param dp is the data provider for arguments.
     */
    public ServiceExecutor(TaskDescription taskDesc, ExecutionInterface execution, org.jboss.txbridge.ba.execute.DataProvider dp)
    {
        log.info("constructor()");
        this.taskDescription = taskDesc;
        this.execution = execution;
        this.dataProvider = dp;
    }

    /**
     * This method sets a new execution type.
     *
     * @param execution is the execution type which should be set.
     */
    public void setExecutionType(ExecutionInterface execution)
    {
        log.info("setExecutionType()");
        this.execution = execution;
    }

    /**
     * This method invokes the datamgmt task which is specified in the service description.
     * It uses datamgmt data which are passed as a parameter.
     *
     * @param md represents the service description.
     * @param edp represents the datamgmt data provider.
     * @throws ActionExecutionException if it was not possible to execute datamgmt action.
     */
    public void invokeService(MethodDescription md, ExecutionDataProvider edp)
            throws ActionExecutionException {
        log.info("invokeService()");
        log.info("Getting list of arguments");
        Object[] arguments = dataProvider.getArguments(md,edp);
        log.info("Getting list of argument types");
        Class[] argumentTypes = dataProvider.getArgumentTypes(arguments);
        Long threadId = Thread.currentThread().getId();
        log.info("Associating datamgmt manager to thread: " + threadId);
        cmp.associateCompensationManager(threadId,new DataManagerImpl(taskDescription.getTaskId(),taskDescription.getParticipant()));
        try
        {
            execution.invokeService(taskDescription,md,arguments,argumentTypes);
            log.info("Removing datamgmt manager association for thread: " + threadId);
            cmp.removeCompensationManager(threadId);
        }
        catch (ActionExecutionException e)
        {
            log.info("Removing datamgmt manager association for thread: " + threadId);
            cmp.removeCompensationManager(threadId);
            throw new ActionExecutionException(e);
        }
    }


}
