/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package com.jboss.ba.demo.service;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Collection;
import java.util.ArrayList;

/**
 * Entity bean that represents a customer object.
 * 
 * @author Maciej P. Machulak (mmachulak@redhat.com)
 * @version 0.1
 */
@Entity
@Table(name = "customer")
public class CustomerEntityImpl implements Serializable
{
    private int id;
    private String username;
    private String password;
    private Collection<OrderEntityImpl> orders = new ArrayList<OrderEntityImpl>();

    public CustomerEntityImpl()
    {
    }

    @Id
    @GeneratedValue
    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }


    public String getUsername()
    {
        return username;
    }

    public void setUsername(String username)
    {
        this.username = username;
    }

    public String getPassword()
    {
        return password;
    }

    public void setPassword(String password)
    {
        this.password = password;
    }

    @Column(name="bookings")
    @OneToMany(mappedBy="customer",
            cascade={CascadeType.REMOVE})
    public Collection<OrderEntityImpl> getOrders()
    {
        return orders;
    }

    public void setOrders(Collection<OrderEntityImpl> orders)
    {
        this.orders = orders;
    }


    @Override
    public String toString()
    {
        StringBuffer sb = new StringBuffer();
        sb.append("ID: ").append(id);
        sb.append(" Username: ").append(username);
        sb.append(" Password: ").append(password);
        return sb.toString();
    }
}
