/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package com.jboss.ba.demo.service;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Entity bean that represents the room object.
 *
 * @author Maciej P. Machulak (mmachulak@redhat.com)
 * @version 0.1
 */
@Entity
@Table(name = "room")
public class RoomEntityImpl implements Serializable
{
    private int id;
	private int roomNumber;
    private String roomName;
    private OrderEntityImpl order;

    public RoomEntityImpl()
    {
    }

    @Id
    @GeneratedValue
    public int getId()
    {
        return id;
    }

    public void setRoomNumber(int roomNumber)
    {
        this.roomNumber = roomNumber;
    }

    public int getRoomNumber()
    {
        return roomNumber;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getRoomName()
    {
        return roomName;
    }

    public void setRoomName(String roomName)
    {
        this.roomName = roomName;
    }

    @OneToOne(mappedBy="room")
    public OrderEntityImpl getOrder()
    {
        return order;
    }

    public void setOrder(OrderEntityImpl order)
    {
        this.order = order;
    }


    @Override
    public String toString()
    {
        StringBuffer sb = new StringBuffer();
        sb.append("Room no: ").append(roomNumber);
        sb.append(" Name: ").append(roomName);
        return sb.toString();
    }

}
