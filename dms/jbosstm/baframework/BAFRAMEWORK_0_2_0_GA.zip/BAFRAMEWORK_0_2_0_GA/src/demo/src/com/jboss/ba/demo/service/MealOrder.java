/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package com.jboss.ba.demo.service;

/**
 * @author Maciej P. Machulak (mmachulak@redhat.com)
 * @version 0.1
 */
public class MealOrder
{
    private int mealId;
    private String name;


    public MealOrder()
    {
    }

    public MealOrder(int mealId,String name)
    {
        this();
        this.mealId = mealId;
        this.name = name;
    }

    public int getMealId()
    {
        return mealId;
    }

    public String getName()
    {
        return name;
    }


    public void setMealId(int mealId)
    {
        this.mealId = mealId;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    @Override
    public String toString()
    {
        StringBuffer sb = new StringBuffer();
        sb.append("Meal Order:");
        sb.append("\n1) ID: ");
        sb.append(mealId);
        sb.append("\n2) Name: ");
        sb.append(name);
        return sb.toString();
    }
}
