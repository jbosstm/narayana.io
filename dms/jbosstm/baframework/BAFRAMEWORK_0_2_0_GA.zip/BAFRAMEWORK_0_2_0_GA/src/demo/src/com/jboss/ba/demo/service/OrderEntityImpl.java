/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package com.jboss.ba.demo.service;

import javax.persistence.*;
import java.io.Serializable;
import java.util.*;

/**
 * Entity bean that represents the order object.
 *
 * @author Maciej P. Machulak (mmachulak@redhat.com)
 * @version 0.1
 */
@Entity
@Table(name="orders")
public class OrderEntityImpl implements Serializable
{
    private int id;
    private CustomerEntityImpl customer;
    private RoomEntityImpl room;
    private Integer fitnessPass = 0;
    private Integer freePack;
    private List<Integer> casinoTokens;
    private boolean extraMiniBar = false;
    private Map<Integer,MealOrder> mealOrders;

    public OrderEntityImpl()
    {
        casinoTokens = new ArrayList<Integer>();
        mealOrders = new HashMap<Integer,MealOrder>();
    }


    public OrderEntityImpl(CustomerEntityImpl customer, RoomEntityImpl room)
    {
        this.customer = customer;
        this.room = room;
    }

    @Id
    @GeneratedValue
    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    @ManyToOne
    @JoinColumn(name="customer")
    public CustomerEntityImpl getCustomer()
    {
        return customer;
    }

    public void setCustomer(CustomerEntityImpl customer)
    {
        this.customer = customer;
    }

    @OneToOne
    @JoinColumn(name="room")
    public RoomEntityImpl getRoom()
    {
        return room;
    }

    public void setRoom(RoomEntityImpl room)
    {
        this.room = room;
    }

    public Integer getFitnessPass()
    {
        return fitnessPass;
    }

    public void setFitnessPass(Integer fitnessPass)
    {
        this.fitnessPass = fitnessPass;
    }

    public Integer getFreePack()
    {
        return freePack;
    }

    public void setFreePack(Integer freePack)
    {
        this.freePack = freePack;
    }

    public void addCasinoToken(Integer token)
    {
        casinoTokens.add(token);
    }

    public boolean removeCasinoToken(Integer casinoToken)
    {
        return casinoTokens.remove(casinoToken);
    }

    public boolean isExtraMiniBar()
    {
        return extraMiniBar;
    }

    public void setExtraMiniBar(boolean extraMiniBar)
    {
        this.extraMiniBar = extraMiniBar;
    }

    public void addMealOrder(MealOrder mealOrder)
    {
        mealOrders.put(mealOrder.getMealId(),mealOrder);
    }

    public boolean removeMealOrder(Integer mealId)
    {
        MealOrder mealOrder = mealOrders.remove(mealId);
        return mealOrder == null;
    }


    @Override
    public String toString()
    {
        StringBuffer sb = new StringBuffer();
        sb.append("ID: ").append(id);
        sb.append(" Customer: ").append(customer.getUsername());
        sb.append(" Room: ").append(room.getRoomName());
        sb.append(" Fitness: ").append(fitnessPass);
        sb.append(" Free pack: ").append(freePack);
        sb.append(" Casino Tokens: ").append(casinoTokens);
        return sb.toString();
    }
}
