/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package com.jboss.ba.demo.service;

import org.jboss.txbridge.ba.annotation.BAParam;

import javax.jws.WebService;

/**
 * @author Maciej P. Machulak (mmachulak@redhat.com)
 * @version 0.1
 */
@WebService
public interface Hotel
{
    // Services:

    // - READ_ONLY
    public String getHotelInfo();
    // - MODIFY - parameters match (BA service as a compensation method)
    public boolean increaseHotelRating(String username,String password,Integer points);
    public boolean decreaseHotelRating(String username,String password,Integer points);
    // - MODIFY - SINGLETON
    public Integer getComplimentaryPackageNumber(String username,String password,Integer reservationNumber) throws HotelCustomException;
    public boolean cancelComplimentaryPackageNumber(String username,String password,Integer reservationNumber) throws HotelCustomException;
    // - MODIFY - NORMAL
    // * custom
    public Integer bookRoom(String username, String password, Integer roomNumber) throws HotelCustomException, RoomAlreadyOccupiedException;
    public boolean cancelRoom(String username,String password,Integer reservationNumber) throws HotelCustomException;
    // * parameters match
    public boolean bookFitnessPass(String username, String password, Integer reservationNumber, Integer amount) throws HotelCustomException;
    public boolean cancelFitnessPass(String username, String password, Integer reservationNumber, Integer amount) throws HotelCustomException;
    public boolean checkoutFitnessPass(String username, String password, Integer reservationNumber);
    // * return value
    public Integer getCasinoToken(String username,String password, Integer amount) throws HotelCustomException;
    public boolean cancelCasinoToken(Integer token) throws HotelCustomException;
    // * compensation manager used
    public MealOrder orderMeal(String username,String password, Integer reservationNumber) throws HotelCustomException;
    public boolean cancelMeal(String username,String password,Integer reservationNumber,Integer orderNumber) throws HotelCustomException;
    // * compensation manager used for additional objects
    public boolean orderExtraMiniBar(String username, String password, Integer reservationNumber)  throws HotelCustomException;
    public boolean cancelExtraMiniBar(String username, String password, Integer reservationNumber) throws HotelCustomException;


    // Control methods
    public void initialiseHotel(String[][] users,Integer rooms);
    public void dropHotelData();
    public void showCompensation();
    public void compensationView(boolean value);
    public void resetView();
    public String getHotelData();
    public String getHotelOrders();

}
