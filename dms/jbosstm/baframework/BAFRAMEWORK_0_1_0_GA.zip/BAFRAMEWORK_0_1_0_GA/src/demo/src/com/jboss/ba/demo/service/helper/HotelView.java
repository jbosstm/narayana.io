/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package com.jboss.ba.demo.service.helper;

import javax.swing.*;
import java.awt.*;

/**
 * @author: Maciej P. Machulak
 * @date: Jul 1, 2007
 */
public class HotelView extends JFrame
{
    private volatile static HotelView hotelView;

    private JTextArea textArea;
    private JScrollPane scrollPane;

    private HotelView()
    {
        setLayout(new BorderLayout());
        setSize(600,900);

        setTitle("BA Framework Test Application - DEBUG Window");

        textArea = new JTextArea(40,20);
        scrollPane = new JScrollPane();

        scrollPane.setAutoscrolls(true);
        textArea.setEditable(false);
        textArea.setRows(10);
        textArea.setMargin(new java.awt.Insets(5, 5, 5, 5));
        scrollPane.setViewportView(textArea);

        getContentPane().add(scrollPane,BorderLayout.CENTER);
        setVisible(true);
        repaint();

    }

    public static HotelView getSingletonInstance()
    {
        if (hotelView == null)
        {
            synchronized(HotelView.class)
            {
                if (hotelView == null)
                {
                    hotelView = new HotelView();
                }
            }
        }
        return hotelView;
    }

    public void resetHotelView()
    {
        textArea.setText("");
    }

    public void newMethod(String methodName)
    {
        textArea.append("######## " + methodName + " ########\n");
    }

    public void addMessage(String message)
    {
        textArea.append(message + "\n");
    }

    public void endMethod()
    {
        textArea.append("--- end ---\n");
    }

    public void showCompensation()
    {
        textArea.append("\n");
        textArea.append("#-#-#-#-#-#-#-# COMPENSATION #-#-#-#-#-#-#-#\n");
        textArea.append("\n");
    }

}
