/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package org.jboss.txbridge.ba.helper;

import org.jboss.txbridge.ba.annotation.BACompensationManagement;
import org.jboss.txbridge.ba.compensation.CompensationManagerImpl;
import org.jboss.txbridge.ba.compensation.CompensationManager;
import org.jboss.txbridge.ba.data.TaskDescription;
import org.apache.log4j.Logger;

import java.lang.reflect.Field;

/**
 * This component provides a method that can be used to inject a compensation manager to an object on
 * which a compensation action is to be executed. Such compensation manager can be used to retrieve
 * and additional data, which may be required by the compensation action.
 *
 * @author Maciej P. Machulak (mmachulak@redhat.com)
 * @version 0.1
 */
public class CompensationManagement
{
    // Logger
    private static Logger log = Logger.getLogger(CompensationManagement.class);

    public static synchronized Object injectCompensationManager(Object targetObject, TaskDescription taskDesc)
    {
        // Inject the transaction identifier
        log.info("injectCompensationManager()");
        log.info(taskDesc);
        try
        {
            Class clazz = targetObject.getClass();
            log.info("Injecting compensation manager");
            Field[] fields = clazz.getDeclaredFields();
            for (Field singleField : fields)
            {
                BACompensationManagement cm = singleField.getAnnotation(BACompensationManagement.class);
                if (cm != null)
                {
                    if (singleField.getType().equals(CompensationManager.class))
                    {
                        log.info("CompensationManager object found...");
                        log.info("Setting field...");
                        singleField.setAccessible(true);
                        log.info("Injecting...");
                        singleField.set(targetObject,new CompensationManagerImpl(taskDesc.getTaskId(),taskDesc.getParticipant()));
                        log.info("Returning...");
                        return targetObject;
                    }
                }
            }
        }
        catch (IllegalAccessException iae)
        {
            iae.printStackTrace();
            return null;
        }
        return null;
    }
}
