/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package org.jboss.txbridge.ba.participant;

import com.arjuna.wst.*;
import org.apache.log4j.Logger;
import org.jboss.txbridge.ba.SingleTransactionManager;
import org.jboss.txbridge.ba.service.ServiceDescription;

/**
 * Implementation of the Participant that is enlisted for the Business Agreement with Coordinator
 * Completion protocol.
 *
 * @author Maciej P. Machulak (mmachulak@redhat.com)
 * @version 0.1
 */
public class CoordinatorCompletionParticipant extends org.jboss.txbridge.ba.participant.Participant implements BusinessAgreementWithCoordinatorCompletionParticipant
{
    // Logger
    private static Logger log = Logger.getLogger(CoordinatorCompletionParticipant.class);

    /**
     * Constructor.
     *
     * @param txId      is the transaction identifier.
     * @param serviceId is the service identifier.
     * @param stm is the single transaction manager.
     * @param cdf is the compensation data factory that should be used by the participant
     */
    public CoordinatorCompletionParticipant(String txId, String serviceId, SingleTransactionManager stm, CompensationDataFactory cdf)
    {
        super(txId, serviceId, stm, cdf);
        log.info("constructor()");
    }

    public void close() throws WrongStateException, SystemException
    {
        log.info("close()");
        closeTransaction();
    }

    public void cancel() throws WrongStateException, SystemException
    {
        log.info("cancel()");
    }

    public void compensate() throws FaultedException, WrongStateException, SystemException
    {
        log.info("compensate()");
        compensateTransaction();
    }

    public String status() throws SystemException
    {
        log.info("status()");
        return null;
    }

    public void unknown() throws SystemException
    {
        log.info("unknown()");
    }

    public void error() throws SystemException
    {
        log.info("error()");
    }

    public void complete() throws WrongStateException, SystemException
    {
        log.info("complete()");
        ServiceDescription sd = sim.getServiceById(serviceId);
        try
        {
            stm.complete(taskList.get(0),sd.getServiceType());
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
