/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package org.jboss.txbridge.ba.compensation;

import org.apache.log4j.Logger;
import org.jboss.txbridge.ba.participant.Participant;

/**
 * Compensation Manager provides a lightweight API for the Business Programmer so that
 * it can store any additional data which may be required by the compensation action.
 * In low-level details it wraps a participant associated with the current service
 * invocation.
 * Compensation Manager is automatically injected by the underlying middleware mechanisms.
 *
 * @author Maciej P. Machulak (mmachulak@redhat.com)
 * @version 0.1
 */
public class CompensationManagerImpl implements CompensationManager
{
    // Logger
    private static Logger log = Logger.getLogger(CompensationManagerImpl.class);

    // Task identifier
    String taskId;

    // Participant
    Participant participant;

    /**
     * Constructor
     *
     * @param taskId is the task identifier.
     * @param participant is the reference to the participant.
     */
    public CompensationManagerImpl(String taskId, Participant participant)
    {
        log.info("constructor()");
        this.taskId = taskId;
        this.participant = participant;
    }

    /**
     * This method stores an object with a given ID. It uses the participant it is aware of and
     * the task identifier.
     *
     * @param objectId is the ID of the object.
     * @param object is the object itself :)
     */
    public void put(Object objectId, Object object)
    {
        log.info("put()");
        participant.put(taskId,objectId,object);
    }

    /**
     * This method retrieves an object with a given identifier. This method automatically
     * associates the task id this compensation manager was associated with.
     *
     * @param objectId is the ID of the object.
     * @return the object.
     */
    public Object get(Object objectId)
    {
        log.info("get()");
        return participant.get(taskId,objectId);
    }
}
