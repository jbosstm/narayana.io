/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package org.jboss.txbridge.ba.service;

import org.jboss.txbridge.ba.annotation.*;

import java.io.Serializable;

/**
 * @author Maciej P. Machulak (mmachulak@redhat.com)
 * @version 0.1
 */
public interface ServiceDescription extends Serializable
{
    BAServiceType getServiceType();

    void setServiceType(BAServiceType serviceType);

    BAAgreementType getAgreementType();

    void setAgreementType(BAAgreementType agreementType);

    BACompensationType getCompensationType();

    void setCompensationType(BACompensationType compensationType);

    public BACompensationMode getCompensationMode();

    public void setCompensationMode(BACompensationMode compensationMode);

    Class getOriginalClass();

    void setOriginalClass(Class originalClass);

    String getOriginalMethodName();

    void setOriginalMethodName(String originalMethodName);

    String getOriginalWebMethodName();

    void setOriginalWebMethodName(String originalWebMethodName);

    Class getOriginalReturnType();

    void setOriginalReturnType(Class originalReturnType);

    Class getCompensationClass();

    void setCompensationClass(Class compensationClass);

    String getCompensationMethodName();

    void setCompensationMethodName(String compensationMethodName);

    String getCompensationWebMethodName();

    void setCompensationWebMethodName(String compensationWebMethodName);

    Class getCompensationReturnType();

    void setCompensationReturnType(Class compensationReturnType);

    public Class[] getOriginalParameterTypes();

    public void setOriginalParameterTypes(Class[] originalParameterTypes);

    public Class[] getCompensationParameterTypes();

    public void setCompensationParameterTypes(Class[] compensationParameterTypes);

    public Object getOriginalReturnId();

    public void setOriginalReturnId(Object originalReturnId);

    public Object[] getOriginalParameterAnnotations();

    public void setOriginalParameterAnnotations(Object[] originalParameterAnnotations);

    public Object[] getCompensationParameterAnnotations();

    public void setCompensationParameterAnnotations(Object[] compensationParameterAnnotations);

    public BAParameterMatch getParameterMatch();

    public void setParameterMatch(BAParameterMatch parameterMatch);

    public String getCompensationJNDIName();

    public void setCompensationJNDIName(String jndiName);

    public String getCompensationProviderURL();

    public void setCompensationProviderURL(String providerURL);

    public boolean isCompensationSingle();

    public void setCompensationSingle(boolean value);

    public Class getCompensationEjbInterface();

    public void setCompensationEjbInterface(Class ejbInterface);

}
