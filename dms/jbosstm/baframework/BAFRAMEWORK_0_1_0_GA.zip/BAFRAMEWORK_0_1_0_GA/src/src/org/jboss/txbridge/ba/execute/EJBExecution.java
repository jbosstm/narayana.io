/*
 * JBoss, Home of Professional Open Source
 * Copyright 2007, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags.
 * See the copyright.txt in the distribution for a full listing
 * of individual contributors.
 * This copyrighted material is made available to anyone wishing to use,
 * modify, copy, or redistribute it subject to the terms and conditions
 * of the GNU General Public License, v. 2.0.
 * This program is distributed in the hope that it will be useful, but WITHOUT A
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License,
 * v. 2.0 along with this distribution; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA  02110-1301, USA.
 *
 * (C) 2007,
 * @author JBoss Inc.
 */
package org.jboss.txbridge.ba.execute;

import org.apache.log4j.Logger;
import org.jboss.txbridge.ba.data.TaskDescription;
import org.jboss.txbridge.ba.exception.CompensationActionUnsuccessfulException;
import org.jboss.txbridge.ba.service.ServiceDescription;

import java.lang.reflect.Method;

/**
 * This class provides implementation of the EJB execution. It uses the Service Locator component
 * to get reference to the required EJB.
 *
 * @author Maciej P. Machulak (mmachulak@redhat.com)
 * @version 0.1
 */
public class EJBExecution implements ExecutionInterface
{
    // Logger
    private static Logger log = Logger.getLogger(EJBExecution.class);

    /**
     * This method invokes a service that is described by the service description with given arguments
     * and argument types.
     *
     * @param taskDesc describes the task (needed to inject the proper participant).
     * @param sd describes the service.
     * @param arguments is the list of arguments.
     * @param argumentTypes is the list of argument types.
     * @throws CompensationActionUnsuccessfulException if invoking compensation action was not successful.
     */
    public void invokeService(TaskDescription taskDesc, ServiceDescription sd, Object[] arguments, Class[] argumentTypes)
            throws CompensationActionUnsuccessfulException
    {
        log.info("invokeService()");
        try
        {

            // Get necessary data
            log.info("Getting necessary data");
            String providerURL = sd.getCompensationProviderURL();
            log.info("Provider URL: " + providerURL);
            String ejbName = sd.getCompensationJNDIName();
            log.info("EJB name: " + ejbName);
            Class ejbInterface = sd.getCompensationEjbInterface();
            log.info("EJB interface: " + ejbInterface);
            String methodName = sd.getCompensationMethodName();

            // Lookup the bean
            log.info("Getting the Service Locator");
            ServiceLocator serviceLocator = ServiceLocator.getInstance(providerURL);
            Object theBean = serviceLocator.getInterface(ejbName,ejbInterface);
            log.info("Bean looked up successfully: " + theBean.getClass());

            // Invoke the method
            log.info("Getting compensation method");
            Method compensationMethod = ejbInterface.getMethod(methodName,argumentTypes);
            if (compensationMethod == null)
            {
                throw new CompensationActionUnsuccessfulException("Could not get access to the compensation method");
            }
            log.info("Invoking compensation method");
            compensationMethod.invoke(theBean,arguments);
        }
        catch (Exception e)
        {
            throw new CompensationActionUnsuccessfulException(e);
        }
    }
}
